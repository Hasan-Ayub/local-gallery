#import <UIKit/UIKit.h>
#import <Photos/Photos.h>
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>

#pragma mark - Full-screen image viewer

@interface GalleryImageViewController : UIViewController <UIScrollViewDelegate>
@property (nonatomic, strong) UIImage *image;
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIImageView *imageView;
- (instancetype)initWithImage:(UIImage *)image;
@end

@implementation GalleryImageViewController

- (instancetype)initWithImage:(UIImage *)image {
    self = [super init];
    if (self) {
        _image = image;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = [UIColor blackColor];

    self.scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    self.scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.scrollView.delegate = self;
    self.scrollView.minimumZoomScale = 1.0;
    self.scrollView.maximumZoomScale = 4.0;
    self.scrollView.showsHorizontalScrollIndicator = NO;
    self.scrollView.showsVerticalScrollIndicator = NO;
    [self.view addSubview:self.scrollView];

    self.imageView = [[UIImageView alloc] initWithImage:self.image];
    self.imageView.contentMode = UIViewContentModeScaleAspectFit;
    [self.scrollView addSubview:self.imageView];
    [self fitImage];

    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]
        initWithBarButtonSystemItem:UIBarButtonSystemItemDone
        target:self
        action:@selector(close)];

    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
        initWithBarButtonSystemItem:UIBarButtonSystemItemAction
        target:self
        action:@selector(shareImage)];

    UITapGestureRecognizer *doubleTap = [[UITapGestureRecognizer alloc]
        initWithTarget:self
        action:@selector(doubleTapped:)];
    doubleTap.numberOfTapsRequired = 2;
    [self.scrollView addGestureRecognizer:doubleTap];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    [self fitImage];
}

- (void)fitImage {
    CGSize boundsSize = self.scrollView.bounds.size;
    CGSize imageSize = self.image.size;
    if (imageSize.width <= 0 || imageSize.height <= 0 || boundsSize.width <= 0 || boundsSize.height <= 0) {
        return;
    }
    CGFloat scale = MIN(boundsSize.width / imageSize.width, boundsSize.height / imageSize.height);
    CGFloat width = imageSize.width * scale;
    CGFloat height = imageSize.height * scale;
    self.imageView.frame = CGRectMake(0, 0, width, height);
    self.scrollView.contentSize = CGSizeMake(width, height);
    self.imageView.center = CGPointMake(boundsSize.width / 2.0, boundsSize.height / 2.0);
}

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView {
    return self.imageView;
}

- (void)scrollViewDidZoom:(UIScrollView *)scrollView {
    CGSize boundsSize = scrollView.bounds.size;
    CGSize contentSize = scrollView.contentSize;
    CGFloat x = (boundsSize.width > contentSize.width) ? (boundsSize.width - contentSize.width) / 2.0 : 0.0;
    CGFloat y = (boundsSize.height > contentSize.height) ? (boundsSize.height - contentSize.height) / 2.0 : 0.0;
    self.imageView.center = CGPointMake(x + contentSize.width / 2.0, y + contentSize.height / 2.0);
}

- (void)doubleTapped:(UITapGestureRecognizer *)gesture {
    if (self.scrollView.zoomScale > 1.0) {
        [self.scrollView setZoomScale:1.0 animated:YES];
    } else {
        CGPoint point = [gesture locationInView:self.imageView];
        [self.scrollView zoomToRect:CGRectMake(point.x, point.y, 1.0, 1.0) animated:YES];
    }
}

- (void)close {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)shareImage {
    UIActivityViewController *activity = [[UIActivityViewController alloc]
        initWithActivityItems:@[self.image]
        applicationActivities:nil];
    if (activity.popoverPresentationController) {
        activity.popoverPresentationController.sourceView = self.view;
    }
    [self presentViewController:activity animated:YES completion:nil];
}

@end

#pragma mark - Gallery

@interface GalleryViewController : UICollectionViewController <PHPhotoLibraryChangeObserver>
@property (nonatomic, strong) NSArray *items;
@end

@implementation GalleryViewController

- (instancetype)init {
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    CGFloat spacing = 2.0;
    NSInteger columns = ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad) ? 5 : 4;
    CGFloat side = ([UIScreen mainScreen].bounds.size.width - spacing * (columns + 1)) / columns;
    layout.itemSize = CGSizeMake(side, side);
    layout.minimumInteritemSpacing = spacing;
    layout.minimumLineSpacing = spacing;
    layout.sectionInset = UIEdgeInsetsMake(spacing, spacing, spacing, spacing);

    self = [super initWithCollectionViewLayout:layout];
    if (self) {
        self.title = @"My Gallery";
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.collectionView.backgroundColor = [UIColor blackColor];
    self.collectionView.alwaysBounceVertical = YES;
    [self.collectionView registerClass:[UICollectionViewCell class]
            forCellWithReuseIdentifier:@"MediaCell"];

    self.navigationController.navigationBar.barTintColor = [UIColor colorWithRed:0.04 green:0.06 blue:0.08 alpha:1.0];
    self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:0.30 green:0.83 blue:0.67 alpha:1.0];
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName: [UIColor whiteColor]};
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
        initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh
        target:self
        action:@selector(loadAssets)];

    [[PHPhotoLibrary sharedPhotoLibrary] registerChangeObserver:self];
    [self checkPhotoAccess];
}

- (void)dealloc {
    [[PHPhotoLibrary sharedPhotoLibrary] unregisterChangeObserver:self];
}

- (void)checkPhotoAccess {
    PHAuthorizationStatus status = [PHPhotoLibrary authorizationStatus];
    if (status == PHAuthorizationStatusNotDetermined) {
        [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus newStatus) {
            dispatch_async(dispatch_get_main_queue(), ^{
                if (newStatus == PHAuthorizationStatusAuthorized) {
                    [self loadAssets];
                } else {
                    [self showAccessAlert];
                }
            });
        }];
    } else if (status == PHAuthorizationStatusAuthorized) {
        [self loadAssets];
    } else {
        [self showAccessAlert];
    }
}

- (void)showAccessAlert {
    UIAlertController *alert = [UIAlertController
        alertControllerWithTitle:@"Photo access needed"
        message:@"Enable access in Settings → Privacy → Photos → My Gallery."
        preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)loadAssets {
    PHFetchOptions *options = [[PHFetchOptions alloc] init];
    options.sortDescriptors = @[[NSSortDescriptor sortDescriptorWithKey:@"creationDate" ascending:NO]];

    PHFetchResult *result = [PHAsset fetchAssetsWithOptions:options];
    NSMutableArray *allItems = [NSMutableArray array];
    for (PHAsset *asset in result) {
        if (asset.mediaType == PHAssetMediaTypeImage || asset.mediaType == PHAssetMediaTypeVideo) {
            [allItems addObject:asset];
        }
    }
    self.items = [NSArray arrayWithArray:allItems];
    self.title = [NSString stringWithFormat:@"My Gallery (%lu)", (unsigned long)self.items.count];
    [self.collectionView reloadData];
}

- (void)photoLibraryDidChange:(PHChange *)changeInstance {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self loadAssets];
    });
}

#pragma mark UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.items.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView
                  cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"MediaCell"
                                                                          forIndexPath:indexPath];
    for (UIView *subview in [cell.contentView.subviews copy]) {
        [subview removeFromSuperview];
    }

    NSInteger expectedTag = indexPath.item;
    cell.tag = expectedTag;

    PHAsset *asset = [self.items objectAtIndex:indexPath.item];

    UIImageView *thumbnail = [[UIImageView alloc] initWithFrame:cell.contentView.bounds];
    thumbnail.contentMode = UIViewContentModeScaleAspectFill;
    thumbnail.clipsToBounds = YES;
    thumbnail.backgroundColor = [UIColor colorWithWhite:0.10 alpha:1.0];
    [cell.contentView addSubview:thumbnail];

    PHImageRequestOptions *requestOptions = [[PHImageRequestOptions alloc] init];
    requestOptions.deliveryMode = PHImageRequestOptionsDeliveryModeFastFormat;
    requestOptions.resizeMode = PHImageRequestOptionsResizeModeFast;
    requestOptions.networkAccessAllowed = NO;

    [[PHImageManager defaultManager]
        requestImageForAsset:asset
                  targetSize:CGSizeMake(240.0, 240.0)
                 contentMode:PHImageContentModeAspectFill
                     options:requestOptions
               resultHandler:^(UIImage *resultImage, NSDictionary *info) {
                   if (cell.tag == expectedTag && resultImage) {
                       thumbnail.image = resultImage;
                   }
               }];

    if (asset.mediaType == PHAssetMediaTypeVideo) {
        UILabel *badge = [[UILabel alloc] initWithFrame:CGRectMake(cell.contentView.bounds.size.width - 46.0, 4.0, 42.0, 16.0)];
        badge.text = @"VIDEO";
        badge.font = [UIFont boldSystemFontOfSize:9.0];
        badge.textColor = [UIColor whiteColor];
        badge.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.65];
        badge.textAlignment = NSTextAlignmentCenter;
        [cell.contentView addSubview:badge];
    }

    return cell;
}

#pragma mark UICollectionViewDelegate

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    PHAsset *asset = [self.items objectAtIndex:indexPath.item];

    if (asset.mediaType == PHAssetMediaTypeVideo) {
        [[PHImageManager defaultManager]
            requestAVAssetForVideo:asset
                           options:nil
                     resultHandler:^(AVAsset *avAsset, AVAudioMix *audioMix, NSDictionary *info) {
                         if (!avAsset) {
                             return;
                         }
                         AVPlayerViewController *playerController = [[AVPlayerViewController alloc] init];
                         playerController.player = [AVPlayer playerWithPlayerItem:[AVPlayerItem playerItemWithAsset:avAsset]];
                         dispatch_async(dispatch_get_main_queue(), ^{
                             [self presentViewController:playerController animated:YES completion:^{
                                 [playerController.player play];
                             }];
                         });
                     }];
    } else {
        [[PHImageManager defaultManager]
            requestImageDataForAsset:asset
                             options:nil
                       resultHandler:^(NSData *imageData, NSString *dataUTI, UIImageOrientation orientation, NSDictionary *info) {
                           UIImage *fullImage = [UIImage imageWithData:imageData];
                           if (!fullImage) {
                               return;
                           }
                           GalleryImageViewController *viewer = [[GalleryImageViewController alloc] initWithImage:fullImage];
                           UINavigationController *viewerNav = [[UINavigationController alloc] initWithRootViewController:viewer];
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [self presentViewController:viewerNav animated:YES completion:nil];
                           });
                       }];
    }
}

@end

#pragma mark - App delegate

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic, strong) UIWindow *window;
@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];

    GalleryViewController *gallery = [[GalleryViewController alloc] init];
    UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:gallery];

    self.window.rootViewController = navigation;
    [self.window makeKeyAndVisible];
    return YES;
}

@end

int main(int argc, char *argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
