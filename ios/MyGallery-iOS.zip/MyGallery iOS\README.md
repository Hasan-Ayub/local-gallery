# My Gallery (native iOS app for jailbroken iPhone 6)

A real native app, not a website. It uses **PhotoKit** to read **every photo and
video in the camera roll automatically** — no file picker, no multi-select
problem. Tap a photo to zoom/share; tap a video to play. The gallery refreshes
when the photo library changes.

This is a **Theos** project. I could not compile it here (Windows has no iOS
toolchain), so you compile it **on the iPhone** with Theos installed.

## Requirements

- Jailbroken iPhone 6 (tested target: iOS 11–12, arm64).
- From Sileo/Zebra/Cydia install:
  - **Theos** and the iOS toolchain (common repos: `https://repo.theos.dev`, `https://havoc.app`)
  - **OpenSSH**
  - Optional: **AppSync Unified** (`https://cydia.akemi.ai`) if the app does not appear or install complains about signatures.

If your phone is only iCloud/MDM-bypassed but **not jailbroken**, this cannot be
installed.

## Install on the device

From this Windows machine, copy the folder to the phone (replace the IP):

```powershell
scp -r "C:\Users\Hassan Ayub\MyGallery iOS" root@192.168.1.50:/var/root/MyGallery
```

Or unzip `MyGallery-iOS.zip` with Filza into `/var/root/MyGallery`.

Then SSH in and build/install:

```bash
ssh root@192.168.1.50
cd /var/root/MyGallery
make package install
killall SpringBoard
```

Default SSH password is `alpine` — change it after setup.

After respring, open **My Gallery** and tap **Allow** when iOS asks for photo
access. If access was denied earlier: Settings → Privacy → Photos → My Gallery →
**All Photos**.

## Notes

- Bundle ID: `com.hasan.my-gallery`
- Installs to `/Applications` (rootful jailbreak). For a **rootless** jailbreak,
  add `THEOS_PACKAGE_SCHEME=rootless` to the Makefile before building.
- For iOS 10, change `TARGET := iphone:clang:latest:11.0` to `10.0` and
  `MinimumOSVersion` in `Resources/Info.plist` to `10.0`.
- No internet/account/permission beyond Photos is used. Media never leaves the
  device.
